# SHINOTECS site draft

Generated draft files:

- index.html
- company.html
- services.html
- service-welfare.html
- service-care-support.html
- access.html
- recruit.html
- contact.html
- privacy.html
- style.css

Open `index.html` in a browser or publish with GitHub Pages.
